# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['qmsspkg', 'qmsspkg.docs', 'qmsspkg.qmsspkg', 'qmsspkg.tests']

package_data = \
{'': ['*'],
 'qmsspkg': ['.pytest_cache/*', '.pytest_cache/v/cache/*', 'htmlcov/*'],
 'qmsspkg.docs': ['_build/doctrees/*',
                  '_build/doctrees/source/*',
                  '_build/html/*',
                  '_build/html/_modules/*',
                  '_build/html/_modules/qmsspkg/*',
                  '_build/html/_sources/*',
                  '_build/html/_sources/source/*',
                  '_build/html/_static/*',
                  '_build/html/source/*',
                  'source/*']}

install_requires = \
['pandas>=1.1.4,<2.0.0']

setup_kwargs = {
    'name': 'qmsspkg',
    'version': '0.1.0',
    'description': 'Python package that eases the pain of concatenating Pandas categoricals!',
    'long_description': '# qmsspkg \n\n![](https://github.com/tbrambor@gmail.com/qmsspkg/workflows/build/badge.svg) [![codecov](https://codecov.io/gh/tbrambor@gmail.com/qmsspkg/branch/main/graph/badge.svg)](https://codecov.io/gh/tbrambor@gmail.com/qmsspkg) ![Release](https://github.com/tbrambor@gmail.com/qmsspkg/workflows/Release/badge.svg) [![Documentation Status](https://readthedocs.org/projects/qmsspkg/badge/?version=latest)](https://qmsspkg.readthedocs.io/en/latest/?badge=latest)\n\nThis cookiecutter creates a boilerplate for a Python project.\n\n## Installation\n\n```bash\n$ pip install -i https://test.pypi.org/simple/ qmsspkg\n```\n\n## Features\n\n- TODO\n\n## Dependencies\n\n- TODO\n\n## Usage\n\n- TODO\n\n## Documentation\n\nThe official documentation is hosted on Read the Docs: https://qmsspkg.readthedocs.io/en/latest/\n\n## Contributors\n\nWe welcome and recognize all contributions. You can see a list of current contributors in the [contributors tab](https://github.com/tbrambor@gmail.com/qmsspkg/graphs/contributors).\n\n### Credits\n\nThis package was created with Cookiecutter and the UBC-MDS/cookiecutter-ubc-mds project template, modified from the [pyOpenSci/cookiecutter-pyopensci](https://github.com/pyOpenSci/cookiecutter-pyopensci) project template and the [audreyr/cookiecutter-pypackage](https://github.com/audreyr/cookiecutter-pypackage).\n',
    'author': 'Thomas Brambor',
    'author_email': 'tbrambor@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/QMSS-G5072-2020/qmsspkg',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
