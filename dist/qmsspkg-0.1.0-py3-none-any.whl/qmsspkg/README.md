# qmsspkg 

![](https://github.com/tbrambor@gmail.com/qmsspkg/workflows/build/badge.svg) [![codecov](https://codecov.io/gh/tbrambor@gmail.com/qmsspkg/branch/main/graph/badge.svg)](https://codecov.io/gh/tbrambor@gmail.com/qmsspkg) ![Release](https://github.com/tbrambor@gmail.com/qmsspkg/workflows/Release/badge.svg) [![Documentation Status](https://readthedocs.org/projects/qmsspkg/badge/?version=latest)](https://qmsspkg.readthedocs.io/en/latest/?badge=latest)

This cookiecutter creates a boilerplate for a Python project.

## Installation

```bash
$ pip install -i https://test.pypi.org/simple/ qmsspkg
```

## Features

- TODO

## Dependencies

- TODO

## Usage

- TODO

## Documentation

The official documentation is hosted on Read the Docs: https://qmsspkg.readthedocs.io/en/latest/

## Contributors

We welcome and recognize all contributions. You can see a list of current contributors in the [contributors tab](https://github.com/tbrambor@gmail.com/qmsspkg/graphs/contributors).

### Credits

This package was created with Cookiecutter and the UBC-MDS/cookiecutter-ubc-mds project template, modified from the [pyOpenSci/cookiecutter-pyopensci](https://github.com/pyOpenSci/cookiecutter-pyopensci) project template and the [audreyr/cookiecutter-pypackage](https://github.com/audreyr/cookiecutter-pypackage).
